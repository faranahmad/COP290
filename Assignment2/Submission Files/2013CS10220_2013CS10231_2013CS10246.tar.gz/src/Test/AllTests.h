#ifndef AllTESTS_H
#define AllTESTS_H

#include "UserTests.h"
#include "UserBaseTests.h"
#include "Test.h"

bool RunAllTests();

#endif