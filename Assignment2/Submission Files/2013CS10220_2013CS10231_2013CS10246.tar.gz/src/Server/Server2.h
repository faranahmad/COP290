#ifndef SERVER2_H
#define SERVER2_H 

int servermain(int, char**);

#endif