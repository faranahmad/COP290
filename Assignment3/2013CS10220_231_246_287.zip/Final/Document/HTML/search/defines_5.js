var searchData=
[
  ['rightangle',['RIGHTANGLE',['../AI_8h.html#a041ce9f7a094e479ea0aa364ea792788',1,'RIGHTANGLE():&#160;AI.h'],['../OPAI_8h.html#a041ce9f7a094e479ea0aa364ea792788',1,'RIGHTANGLE():&#160;OPAI.h']]]
];
