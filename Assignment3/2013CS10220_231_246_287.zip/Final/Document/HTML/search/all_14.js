var searchData=
[
  ['vectoraliens',['VectorAliens',['../classBoard.html#a8314122d17536c280bebf1c015522175',1,'Board']]],
  ['vectorbullets',['VectorBullets',['../classBoard.html#a2dc362255acf464278a688d03c7d0756',1,'Board']]],
  ['vectorships',['VectorShips',['../classBoard.html#a18dfdb96f49cf35d7bd480b22ca232b4',1,'Board']]],
  ['velx',['VelX',['../classBullet.html#a4d587ab4f71d1f6d3681507b04674bfb',1,'Bullet']]],
  ['vely',['VelY',['../classBullet.html#a567e3c286f1e47015314b7ef141cf8d9',1,'Bullet']]],
  ['verbose',['verbose',['../classTest.html#ab02c0c474b2a636c948baf761df0b3c5',1,'Test']]],
  ['verifyfalse',['VerifyFalse',['../classTest.html#a719a8eb78ad30689d4b1292d8ed8c6e0',1,'Test']]],
  ['verifytrue',['VerifyTrue',['../classTest.html#aa7b8f1adb896473e046835503af76c1d',1,'Test']]],
  ['viewtotake',['viewtotake',['../Combined_8h.html#a33fbcbc90b1d9c65d170911abe24c691',1,'viewtotake():&#160;Combined.h'],['../CompCombined_8h.html#a33fbcbc90b1d9c65d170911abe24c691',1,'viewtotake():&#160;CompCombined.h']]]
];
