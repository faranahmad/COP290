var searchData=
[
  ['z',['z',['../structPoints.html#a4f659e794599309880a47bb4b78c0e97',1,'Points']]]
];
