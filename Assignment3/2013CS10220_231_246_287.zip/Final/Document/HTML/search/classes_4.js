var searchData=
[
  ['expl',['Expl',['../structExpl.html',1,'']]]
];
