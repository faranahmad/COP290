var searchData=
[
  ['whatitshoulddo',['WhatItShouldDo',['../AI_8h.html#a6c06c6b568fbc9b07d9fc73f38ef4ba3',1,'AI.h']]],
  ['width',['width',['../classImage.html#ab8d12f635013c04159cd4d3d972bac88',1,'Image']]]
];
