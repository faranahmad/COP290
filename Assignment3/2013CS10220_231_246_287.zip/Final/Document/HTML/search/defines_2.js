var searchData=
[
  ['maximumdistance',['maximumdistance',['../AI_8cpp.html#a3a2e5f6829d44ff9c5abfea7b5e4d9ee',1,'maximumdistance():&#160;AI.cpp'],['../OriginalAI_8cpp.html#a3a2e5f6829d44ff9c5abfea7b5e4d9ee',1,'maximumdistance():&#160;OriginalAI.cpp']]],
  ['minangleofrotation',['minAngleofRotation',['../AI_8cpp.html#a3f93ce40393c09a5ce19c9e8d0fccebd',1,'minAngleofRotation():&#160;AI.cpp'],['../AI_8h.html#a3f93ce40393c09a5ce19c9e8d0fccebd',1,'minAngleofRotation():&#160;AI.h'],['../OPAI_8h.html#a3f93ce40393c09a5ce19c9e8d0fccebd',1,'minAngleofRotation():&#160;OPAI.h'],['../OriginalAI_8cpp.html#a3f93ce40393c09a5ce19c9e8d0fccebd',1,'minAngleofRotation():&#160;OriginalAI.cpp']]],
  ['mindistanceforrotation',['minDistanceforRotation',['../AI_8cpp.html#aa9f6f99b26c45a8b855bfc6c170bf560',1,'minDistanceforRotation():&#160;AI.cpp'],['../AI_8h.html#aa9f6f99b26c45a8b855bfc6c170bf560',1,'minDistanceforRotation():&#160;AI.h'],['../OPAI_8h.html#aa9f6f99b26c45a8b855bfc6c170bf560',1,'minDistanceforRotation():&#160;OPAI.h'],['../OriginalAI_8cpp.html#aa9f6f99b26c45a8b855bfc6c170bf560',1,'minDistanceforRotation():&#160;OriginalAI.cpp']]]
];
