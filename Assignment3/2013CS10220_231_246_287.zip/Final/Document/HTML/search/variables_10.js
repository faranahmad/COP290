var searchData=
[
  ['r',['R',['../classColor.html#afb8ce8200a490088d415606620149b82',1,'Color']]],
  ['radius',['radius',['../structSmokePoint.html#ae1552d6e7a1e25de7a6288fec1ab4a44',1,'SmokePoint::radius()'],['../structFirePoint.html#a58564702fea12d591467ab0a61bec63e',1,'FirePoint::radius()']]],
  ['rankingtodisplay',['rankingtodisplay',['../Combined_8h.html#ae18def5b96b0f06a2c222a2de2717540',1,'rankingtodisplay():&#160;Combined.h'],['../CompCombined_8h.html#ae18def5b96b0f06a2c222a2de2717540',1,'rankingtodisplay():&#160;CompCombined.h']]]
];
