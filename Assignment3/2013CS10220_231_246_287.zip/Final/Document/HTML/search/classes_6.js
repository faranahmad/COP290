var searchData=
[
  ['gameplay',['GamePlay',['../structGamePlay.html',1,'']]],
  ['graph',['Graph',['../structGraph.html',1,'']]]
];
