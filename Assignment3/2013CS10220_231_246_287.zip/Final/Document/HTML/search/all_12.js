var searchData=
[
  ['test',['Test',['../classTest.html',1,'Test'],['../classTest.html#aa1a8488c06a34269437ee3d97819d619',1,'Test::Test()']]],
  ['test_2ecpp',['Test.cpp',['../Test_8cpp.html',1,'']]],
  ['test_2eh',['Test.h',['../Test_8h.html',1,'']]],
  ['testmera_2ecpp',['testmera.cpp',['../testmera_8cpp.html',1,'']]],
  ['theta',['theta',['../AI_8cpp.html#aef99e10165c67d902d3caf23b5944c6d',1,'theta():&#160;AI.cpp'],['../AI_8h.html#aef99e10165c67d902d3caf23b5944c6d',1,'theta():&#160;AI.h'],['../OPAI_8h.html#aef99e10165c67d902d3caf23b5944c6d',1,'theta():&#160;OPAI.h'],['../OriginalAI_8cpp.html#aef99e10165c67d902d3caf23b5944c6d',1,'theta():&#160;OriginalAI.cpp']]],
  ['timecreated',['TimeCreated',['../classBullet.html#ab5cc1b11c455b72423ba9a91962dab6b',1,'Bullet']]],
  ['timestamp',['TimeStamp',['../udp_8cpp.html#a2680f996bf880e7e7f52b5a221509520',1,'udp.cpp']]],
  ['titleptr',['titleptr',['../Combined_8h.html#a53ce171bed6a3fd33d31e7c459592aac',1,'titleptr():&#160;Combined.h'],['../CompCombined_8h.html#a53ce171bed6a3fd33d31e7c459592aac',1,'titleptr():&#160;CompCombined.h']]],
  ['toarr',['ToArr',['../udp_8cpp.html#ab07990aa563258ba3ec432e705dff1ee',1,'ToArr(std::string str):&#160;udp.cpp'],['../udp_8h.html#ab07990aa563258ba3ec432e705dff1ee',1,'ToArr(std::string str):&#160;udp.cpp']]],
  ['todigit',['toDigit',['../backupcoop_8cpp.html#a8819b73943c41bec8dbf150e46b94147',1,'toDigit():&#160;backupcoop.cpp'],['../Board_8cpp.html#a8819b73943c41bec8dbf150e46b94147',1,'toDigit():&#160;Board.cpp'],['../CompetitiveBoard_8cpp.html#a8819b73943c41bec8dbf150e46b94147',1,'toDigit():&#160;CompetitiveBoard.cpp']]],
  ['tofour',['ToFour',['../backupcoop_8cpp.html#a1f78de869333297eaeb122baaf4dfea7',1,'ToFour(std::string x):&#160;backupcoop.cpp'],['../Board_8cpp.html#a1f78de869333297eaeb122baaf4dfea7',1,'ToFour(std::string x):&#160;Board.cpp'],['../CompetitiveBoard_8cpp.html#a1f78de869333297eaeb122baaf4dfea7',1,'ToFour(std::string x):&#160;CompetitiveBoard.cpp']]],
  ['tofour1',['ToFour1',['../CompHighscore_8cpp.html#ac3175009e67642ac49f8b6a5d003c3a8',1,'ToFour1(std::string x):&#160;CompHighscore.cpp'],['../Highscore_8cpp.html#ac3175009e67642ac49f8b6a5d003c3a8',1,'ToFour1(std::string x):&#160;Highscore.cpp']]],
  ['tostr',['ToStr',['../udp_8cpp.html#a0cde59c431c055ef0fd880ea2a278498',1,'ToStr(char *arr):&#160;udp.cpp'],['../udp_8h.html#a0cde59c431c055ef0fd880ea2a278498',1,'ToStr(char *arr):&#160;udp.cpp']]],
  ['turn',['Turn',['../AI_8h.html#a6c06c6b568fbc9b07d9fc73f38ef4ba3a0c1b9bb2e704447170944d00fcca57a3',1,'AI.h']]],
  ['turnalienindirectionofship',['TurnAlienInDirectionOfShip',['../AI_8h.html#a97b8df37bb2199d1ecd146f5497cdc5d',1,'TurnAlienInDirectionOfShip(Alien &amp;alien, Ship &amp;ship, bool &amp;finished):&#160;AIalien.cpp'],['../AIalien_8cpp.html#a97b8df37bb2199d1ecd146f5497cdc5d',1,'TurnAlienInDirectionOfShip(Alien &amp;alien, Ship &amp;ship, bool &amp;finished):&#160;AIalien.cpp']]],
  ['turnindirectionof',['TurnInDirectionOf',['../AI_8cpp.html#a2669e8f621a852cf9c4836038b1083b2',1,'TurnInDirectionOf(Ship &amp;ship, Alien &amp;alien):&#160;AI.cpp'],['../AI_8cpp.html#a53fc16ff1d675e14fb84079f309ad402',1,'TurnInDirectionOf(Alien &amp;alien, Ship &amp;ship):&#160;AI.cpp'],['../OriginalAI_8cpp.html#a2669e8f621a852cf9c4836038b1083b2',1,'TurnInDirectionOf(Ship &amp;ship, Alien &amp;alien):&#160;OriginalAI.cpp'],['../OriginalAI_8cpp.html#a53fc16ff1d675e14fb84079f309ad402',1,'TurnInDirectionOf(Alien &amp;alien, Ship &amp;ship):&#160;OriginalAI.cpp']]],
  ['turnshipindirectionofalien',['TurnShipInDirectionOfAlien',['../AI_8h.html#ab5cd8fc4e17a30bca5f4f1b4874557d9',1,'TurnShipInDirectionOfAlien(Ship &amp;ship, Alien &amp;alien, bool &amp;finished):&#160;AIPlayer.cpp'],['../AIPlayer_8cpp.html#ab5cd8fc4e17a30bca5f4f1b4874557d9',1,'TurnShipInDirectionOfAlien(Ship &amp;ship, Alien &amp;alien, bool &amp;finished):&#160;AIPlayer.cpp']]],
  ['typeai',['TypeAI',['../classBullet.html#ae2f8ea9d3c700fc27efafec7d540404a',1,'Bullet']]],
  ['typeplayer',['TypePlayer',['../classBullet.html#ac1315818abe9b9c337af21b14c282868',1,'Bullet']]]
];
