var searchData=
[
  ['turn',['Turn',['../AI_8h.html#a6c06c6b568fbc9b07d9fc73f38ef4ba3a0c1b9bb2e704447170944d00fcca57a3',1,'AI.h']]]
];
