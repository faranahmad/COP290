var searchData=
[
  ['name',['name',['../structIDScore.html#ab16cc900e480c63706a899f89ececc71',1,'IDScore::name()'],['../structIDScore.html#a8c84842bb34c060bde8a3f9d5ee462a5',1,'IDScore::name()'],['../classShip.html#a5c247c8fa3b3781733d80ba4afba7eea',1,'Ship::Name()']]],
  ['negx',['NEGX',['../AI_8h.html#a2d5cf866f344aa65a85828e075e4b3e9',1,'NEGX():&#160;Combined.h'],['../Combined_8h.html#a2d5cf866f344aa65a85828e075e4b3e9',1,'NEGX():&#160;Combined.h'],['../CompCombined_8h.html#a2d5cf866f344aa65a85828e075e4b3e9',1,'NEGX():&#160;CompCombined.h'],['../OPAI_8h.html#a2d5cf866f344aa65a85828e075e4b3e9',1,'NEGX():&#160;Combined.h']]],
  ['negy',['NEGY',['../AI_8h.html#abc10d7ef05980ba384e5d8f63fb96f54',1,'NEGY():&#160;Combined.h'],['../Combined_8h.html#abc10d7ef05980ba384e5d8f63fb96f54',1,'NEGY():&#160;Combined.h'],['../CompCombined_8h.html#abc10d7ef05980ba384e5d8f63fb96f54',1,'NEGY():&#160;CompCombined.h'],['../OPAI_8h.html#abc10d7ef05980ba384e5d8f63fb96f54',1,'NEGY():&#160;Combined.h']]],
  ['newg',['newg',['../Combined_8h.html#a784e2ef9df4012b6db08050986cd92b7',1,'newg():&#160;Combined.h'],['../CompCombined_8h.html#a784e2ef9df4012b6db08050986cd92b7',1,'newg():&#160;CompCombined.h']]],
  ['newhighscore',['NewHighScore',['../Combined_8h.html#ab5e3710df38ae855f98b3337e9612d3d',1,'NewHighScore():&#160;Combined.h'],['../CompCombined_8h.html#ab5e3710df38ae855f98b3337e9612d3d',1,'NewHighScore():&#160;CompCombined.h'],['../CompHighscore_8h.html#ab5e3710df38ae855f98b3337e9612d3d',1,'NewHighScore():&#160;Combined.h'],['../Highscore_8h.html#ab5e3710df38ae855f98b3337e9612d3d',1,'NewHighScore():&#160;Combined.h']]],
  ['noip',['noIP',['../udp_8cpp.html#a38b53963f8ff754dee49d6a19b8ba816',1,'udp.cpp']]],
  ['numberbullets',['NumberBullets',['../classAlien.html#a0759bffcb3f5e8e50f94c4238df3572f',1,'Alien::NumberBullets()'],['../classShip.html#a37320083d8bab0468569c3e115db262f',1,'Ship::NumberBullets()']]],
  ['numbermissiles',['NumberMissiles',['../classAlien.html#acef360d7d4e79ad81fdabacc9c999674',1,'Alien::NumberMissiles()'],['../classShip.html#ab24237be38864d5a3d6ffad7b4d9925b',1,'Ship::NumberMissiles()']]],
  ['nx',['NX',['../Combined_8h.html#a4612f39eb7c9f6765bafb807592b9eb0',1,'NX():&#160;Combined.h'],['../CompCombined_8h.html#a4612f39eb7c9f6765bafb807592b9eb0',1,'NX():&#160;CompCombined.h']]],
  ['ny',['NY',['../Combined_8h.html#a4db4a3cb70d7b58351ff75716a01c75f',1,'NY():&#160;Combined.h'],['../CompCombined_8h.html#a4db4a3cb70d7b58351ff75716a01c75f',1,'NY():&#160;CompCombined.h']]]
];
