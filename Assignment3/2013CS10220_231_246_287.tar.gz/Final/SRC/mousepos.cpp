
void mousepos(int x,int y)
{
	std::cout<<"Mouse postion:("<<x<<","<<y<<")\n";
}

glutPassiveMotionFunc(mousepos);
