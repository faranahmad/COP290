#include "AllTests.h"


bool RunAllTests()
{
	RunAllShipTests();
}

int main()
{
	RunAllTests();
	return 0;
}