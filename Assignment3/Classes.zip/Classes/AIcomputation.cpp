int ClosestAlienEnemy(std::vector<Alien> &Aliens,int NumberAliens, Bullet &actualmissile, double maxDistance)
{
	int closestAlien = -1;
	float leastDistance = maxDistance; //Infinity
	for (int i=0; i<NumberAliens;i++)
	{
		std::cout<<"Inarc "<<InArc(Aliens[i],actualmissile)<<" Distance "<<Distance(Aliens[i],actualmissile)<<"\n";
		if (AlienInArc(Aliens[i],actualmissile)==true && Distance(Aliens[i],actualmissile) < leastDistance)
		{
			leastDistance=DistanceOfAlienFromMissile(Aliens[i],actualmissile);
			closestAlien = i;
			//std::cout<<"closest alien "<<closestAlien<<"\n";
		}
	}
	return closestAlien;
}

int ClosestShipEnemy(std::vector<Ship> &Ships,int NumberShips, Bullet &actualmissile)
{
	int closestShip = -1;
	float leastDistance = 100000; //Infinity
	for (int i=0; i<NumberShips;i++)
	{
		if (ShipInArc(Ships[i],actualmissile) && Distance(Ships[i],actualmissile) < leastDistance)
		{
			leastDistance = DistanceOfShipFromMissile(Ships[i],actualmissile);
			closestShip = i;
		}
	}
	return closestShip;
}

bool AlienInArc(Alien &alien, Bullet &actualmissile)
{
	if (abs(relativeAngleALienFromMissile(alien,actualmissile)*180/PI)<theta)
		return true;
	else 
		return false;
}

bool ShipInArc(Ship &ship, Bullet &actualmissile)
{
	if (abs(relativeShipFromMissileAngle(ship,actualmissile)*180/PI)<theta)
		return true;
	else 
		return false;
}

float relativeAngleAlienFromMissile(Alien &alien,Bullet &actualmissile)
{
	float angle;

	if (alien.GetXPos()-actualmissile.GetXPos() == 0.0)
	{
		if ((alien.GetYPos()-actualmissile.GetYPos())>0)
			angle= (float) 0.0;
		else
			angle= 180.0;
	} 
	else
	{
		if (alien.GetXPos()-actualmissile.GetXPos()>0)
			angle= ((float) atan( (alien.GetYPos()-actualmissile.GetYPos())/ (alien.GetXPos()-actualmissile.GetXPos())) * 180/PI - 90.0);
		else
			angle= ((float) atan((alien.GetYPos()-actualmissile.GetYPos()) / (alien.GetXPos()-actualmissile.GetXPos())) * 180/PI + 90.0);
	}

	//std::cout<<"angle "<<angle<<"\n";
	//std::cout<<"relative angle"<<actualmissile.GetAngle()-angle<<"\n";
	return (actualmissile.GetAngle()-angle)*PI/180.0;
}

float relativeAngleShipFromMissile(Ship &ship,Bullet &actualmissile)
{
	float angle;

	if (ship.GetXPos()-actualmissile.GetXPos() == 0.0)
	{
		if ((ship.GetYPos()-actualmissile.GetYPos())>0)
			angle= (float) 0.0;
		else
			angle= 180.0;
	} 
	else
	{
		if (ship.GetXPos()-actualmissile.GetXPos()>0)
			angle= ((float) atan( (ship.GetYPos()-actualmissile.GetYPos())/ (ship.GetXPos()-actualmissile.GetXPos())) * 180/PI - 90.0);
		else
			angle= ((float) atan((ship.GetYPos()-actualmissile.GetYPos()) / (ship.GetXPos()-actualmissile.GetXPos())) * 180/PI + 90.0);
	}

	return (actualmissile.GetAngle()-angle)*PI/180.0;
}

float relativeAngleAlientoMissilePosition(Alien &alien, Bullet &actualmissile)
{
	float angle;

	if (alien.GetXPos()-actualmissile.GetXPos() == 0.0)
	{
		if ((alien.GetYPos()-actualmissile.GetYPos())>0)
			angle= (float) 0.0;
		else
			angle= 180.0;
	} 
	else
	{
		if (alien.GetXPos()-actualmissile.GetXPos()>0)
			angle= ((float) atan( (alien.GetYPos()-actualmissile.GetYPos())/ (alien.GetXPos()-actualmissile.GetXPos())) * 180/PI - 90.0);
		else
			angle= ((float) atan((alien.GetYPos()-actualmissile.GetYPos()) / (alien.GetXPos()-actualmissile.GetXPos())) * 180/PI + 90.0);
	}

	return angle;

}


float relativeAngleShiptoMissilePosition(Ship &ship, Bullet &actualmissile)
{
	float angle;

	if (ship.GetXPos()-actualmissile.GetXPos() == 0.0)
	{
		if ((ship.GetYPos()-actualmissile.GetYPos())>0)
			angle= (float) 0.0;
		else
			angle= 180.0;
	} 
	else
	{
		if (ship.GetXPos()-actualmissile.GetXPos()>0)
			angle= ((float) atan( (ship.GetYPos()-actualmissile.GetYPos())/ (ship.GetXPos()-actualmissile.GetXPos())) * 180/PI - 90.0);
		else
			angle= ((float) atan((ship.GetYPos()-actualmissile.GetYPos()) / (ship.GetXPos()-actualmissile.GetXPos())) * 180/PI + 90.0);
	}

	return angle;

}

float relativeAngleOfShipfromAlien(Ship &ship,Alien &alien)
{
	float angle;

	if (ship.GetXPos()-alien.GetXPos() == 0.0)
	{
		if ((ship.GetYPos()-alien.GetYPos())>0)
			angle= (float) 0.0;
		else
			angle= 180.0;
	} 
	else
	{
		if (ship.GetXPos()-alien.GetXPos()>0)
			angle= ((float) atan( (ship.GetYPos()-alien.GetYPos())/ (ship.GetXPos()-alien.GetXPos())) * 180/PI - 90.0);
		else
			angle= ((float) atan((ship.GetYPos()-alien.GetYPos()) / (ship.GetXPos()-alien.GetXPos())) * 180/PI + 90.0);
	}

	return angle;
}



float relativeAngleOfAlienFromShip(Alien& alien,Ship &ship)
{
	float angle;

	if (alien.GetXPos()-ship.GetXPos() == 0.0)
	{
		if ((alien.GetYPos()-ship.GetYPos())>0)
			angle= (float) 0.0;
		else
			angle= 180.0;
	} 
	else
	{
		if (alien.GetXPos()-ship.GetXPos()>0)
			angle= ((float) atan( (alien.GetYPos()-ship.GetYPos())/ (alien.GetXPos()-ship.GetXPos())) * 180/PI - 90.0);
		else
			angle= ((float) atan((alien.GetYPos()-ship.GetYPos()) / (alien.GetXPos()-ship.GetXPos())) * 180/PI + 90.0);
	}

	return angle;}

int FindNearestAlien(Ship &ship, std::vector<Alien> &CurrentAliens,bool nearEnough)
{
	float min = maximumdistance;
	int nearestAlien = -1;
	for (int j=0; j<CurrentAliens.size(); j++)
	{
		float dist = Distance(ship,CurrentAliens[j]);
		if (dist < min)
		{
			min = dist;
			nearestAlien = j;
		}
	}

	if (min<=minDistanceforRotation)
		nearEnough = true;
	else 
		nearEnough = false;

	return nearestAlien;

}

int FindNearestShip(Alien &alien, std::vector<Ship> &CurrentShips,bool nearEnough)
{
	float min = maximumdistance;
	int nearestShip = -1;
	for (int j=0; j<CurrentShips.size(); j++)
	{
		float dist=Distance(CurrentShips[j],alien);
		if (dist < min)
		{
			min = dist;
			nearestShip = j;
		}
	}

	if (min<=minDistanceforRotation)
		nearEnough = true;
	else 
		nearEnough = false;

	return nearestShip;

}

float DistanceOfAlienFromMissile(Alien &alien, Bullet &actualmissile)
{
	//include math.h
	return pow((alien.GetXPos() - actualmissile.GetXPos()),2) + pow((alien.GetYPos()-actualmissile.GetYPos()),2);
}

float DistanceOfShipFromMissile(Ship &ship, Bullet &actualmissile)
{
	//include math.h
	return pow((ship.GetXPos()-actualmissile.GetXPos()),2) + pow((ship.GetYPos()-actualmissile.GetYPos()),2);
}

float DistanceOfShipFromAlien(Ship &ship, Alien &alien)
{
	return pow((alien.GetXPos()-ship.GetXPos()),2) + pow((alien.GetYPos()-ship.GetYPos()),2);

}

float DistanceOfAlienFromShip(Alien &alien, Ship &ship)
{
	return pow((alien.GetXPos()-ship.GetXPos()),2) + pow((alien.GetYPos()-ship.GetYPos()),2);

}


