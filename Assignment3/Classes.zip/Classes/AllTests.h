#ifndef AllTESTS_H
#define AllTESTS_H

#include "ShipTest.h"
#include "Test.h"

bool RunAllTests();

#endif