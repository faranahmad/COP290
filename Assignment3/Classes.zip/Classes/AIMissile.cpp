//TODO

//#define theta for InArc
//add acceleration for missiles
//define speed of aliens in terms of alien types and levels
//similarly for ships
//also define speed of rotation for the same
// ask faran for getangle of alien and ship
//relativeangles are in radians-correct
//ask faran how he updates position of ship 


/*To think/test
1.minDistanceforRotation
2.minAngleofRotation/angularvelocity
3.relativeangle ki direction
4. angle so that i can shoot, keep this different for different aliens :)
*/ 
#include "AI.h"
#define theta 45
#define minDistanceforRotation 100
#define minAngleofRotation 15
#define angularvelocity 10
#define maximumdistance 100000
#define RIGHTANGLE 90

// srand(time(NULL));
void UpdateAlienMissile(Board &board)
{
	std::vector<Bullet> CurrentBullets = board.GetVectorBullets();
	std::vector<Ship> CurrentShips = board.GetVectorShips();
	std::vector<Alien> CurrentAliens = board.GetVectorAliens();
	for (int i=0; i<board.GetNumberBullets(); i++)
	{
		if (CurrentBullets[i].GetTypeAI()==true && CurrentBullets[i].GetShipId()==-1)
		{
			std::vector<Ship> temp=board.GetVectorShips();
			int target = ClosestShipEnemy(temp,board.GetNumberShips(),CurrentBullets[i]);
			if (target==-1)
			{

			}
			else
			{
				Ship temp2=board.GetNthShip(target);
				UpdateAlienMissileVelocity(CurrentBullets[i] , temp2);
			}
		}
	}
	board.SetVectorBullets(CurrentBullets);
}

void UpdateShipMissile(Board &board)
{
	std::vector<Bullet> CurrentBullets = board.GetVectorBullets();
	std::vector<Ship> CurrentShips = board.GetVectorShips();
	std::vector<Alien> CurrentAliens = board.GetVectorAliens();
		
	for (int i=0; i<board.GetNumberBullets(); i++)
	{
		if (CurrentBullets[i].GetTypeAI()==true && CurrentBullets[i].GetShipId()!=-1)
		{
			std::vector<Alien> temp=board.GetVectorAliens();
			int target = ClosestAlienEnemy(temp,board.GetNumberAliens(),CurrentBullets[i],board.MaxDistance());
			
			if (target==-1)
			{
				std::cout<<"No target acquired, velocity remains same \n";
			}
			else
			{
				Alien temp2=board.GetNthAlien(target);
				UpdateShipMissileVelocity(CurrentBullets[i],temp2);
			}
		}
	}
	board.SetVectorBullets(CurrentBullets);
}

void UpdateALienMissileVelocity(Bullet &actualmissile,Ship &ship)
{
	float angle=relativeAngleShiptoMissilePosition(ship,actualmissile);
	float speed=actualmissile.GetSpeed();
	actualmissile.SetVelX(speed*cos(angle));
	actualmissile.SetVelY(speed*sin(angle));
}

void UpdateShipMissileVelocity(Bullet &actualmissile,Alien &alien)
{
	float angle=relativeAngleAlientoMissilePosition(alien,actualmissile);
	float speed=actualmissile.GetSpeed();
	actualmissile.SetVelX(speed*cos(angle));
	actualmissile.SetVelY(speed*sin(angle));
}























