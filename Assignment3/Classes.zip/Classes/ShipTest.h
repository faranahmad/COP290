#ifndef SHIPTEST_H
#define SHIPTEST_H

#include "Ship.h"
#include "Test.h"

bool RunAllShipTests();
bool ShipInitialisationTests();
bool SettingShipTests();
bool UpdateShipTests();

#endif