void UpdateAIBoard(Board &board)
{
	UpdatePlayerAI(board);
	UpdateAlien(board);
	UpdateMissile(board);
}

void UpdatePlayerAI(Board &board)
{
	std::vector<Bullet> CurrentBullets = board.GetVectorBullets();
	std::vector<Ship> CurrentShips = board.GetVectorShips();
	std::vector<Alien> CurrentAliens = board.GetVectorAliens();
	for (int i=0;i<CurrentShips.size();i++)
	{
		if (CurrentShips[i].IfAIControl())
		{
			bool nearEnough = false;
			int nearestAlien = FindNearestAlien(CurrentShips[i],CurrentAliens,nearEnough);
			if (nearEnough == false) //no aliens very near
				MoveInDirectionOf(CurrentShips[i],CurrentAliens[nearestAlien]); //should this also have turn in direction of ? I shoul keep both :O
			else
				TurnInDirectionOf(CurrentShips[i],CurrentAliens[nearestAlien]);
		}
	}
	board.SetVectorShips(CurrentShips); 	//actual updation
}

void UpdateAlien(Board &board)
{
	std::vector<Bullet> CurrentBullets = board.GetVectorBullets();
	std::vector<Ship> CurrentShips = board.GetVectorShips();
	std::vector<Alien> CurrentAliens = board.GetVectorAliens();

	for (int i=0; i<CurrentAliens.size();i++)
	{
		
		bool nearEnough = false;
		int nearestShip = FindNearestShip(CurrentAliens[i],CurrentShips,nearEnough);
		if (nearEnough == false) //no ships very near
		{
			MoveInDirectionOf(CurrentAliens[i],CurrentShips[nearestShip]); //should this also have turn in direction of ? I shoul keep both :O
		}
		else
		{
			TurnInDirectionOf(CurrentAliens[i],CurrentShips[nearestShip]);
		}
	}
	board.SetVectorAliens(CurrentAliens); //actual updation
}

void UpdateMissile(Board &board)
{
	UpdateAlienMissile(board);
	UpdateShipMissile(board);
	std::vector<Bullet> VectorBullets=board.GetVectorBullets();
			
	for (int i=0;i<VectorBullets.size();i++)
	{
		if(VectorBullets.at(i).GetTypeAI() == true)
		{
			VectorBullets.at(i).SetXPos(VectorBullets.at(i).GetXPos()+VectorBullets.at(i).GetVelX());
			VectorBullets.at(i).SetYPos(VectorBullets.at(i).GetYPos()+VectorBullets.at(i).GetVelY());
		}
	}
	board.SetVectorBullets(VectorBullets); //actual updation
}