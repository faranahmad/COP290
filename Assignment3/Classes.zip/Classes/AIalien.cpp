void MoveInDirectionOf(Alien &alien, Ship &ship)
{
	float angle=alien.GetAngle();
	if (abs(relativeAngleOfAlienFromShip(ship,alien)-alien.GetAngle())<RIGHTANGLE)
	{
		alien.SetXPos(alien.GetXPos()+5*cos(angle));
		alien.SetYPos(alien.GetYPos()+5*sin(angle));
	}
	else
	{
		alien.SetXPos(alien.GetXPos()-5*cos(angle));
		alien.SetYPos(alien.GetYPos()-5*sin(angle));
	}
}

void TurnInDirectionOf(Alien &alien, Ship &ship)
{
	float alienAngle = alien.GetAngle();
	if (abs(relativeAngleOfAlienFromShip(alien,ship)) < minAngleofRotation)
		alien.SetAngle(alienAngle+relativeAngle(alien,ship));//check
	else
		alien.SetAngle(alienAngle+angularvelocity);//change the sign of this according to where the alien is
}