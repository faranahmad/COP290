void MoveInDirectionOf(Ship &ship, Alien &alien)
{
	float angle=ship.GetAngle();
	if (abs(relativeAngleOfShipFromALien(alien,ship)-ship.GetAngle())<RIGHTANGLE)
	{
		
		ship.SetXPos(ship.GetXPos()+5*cos(angle));
		ship.SetYPos(ship.GetYPos()+5*sin(angle));
	}
	else
	{
		ship.SetXPos(ship.GetXPos()-5*cos(angle));
		ship.SetYPos(ship.GetYPos()-5*sin(angle));
	}
}

void TurnInDirectionOf(Ship &ship, Alien &alien)
{
	float shipAngle = ship.GetAngle();
	if (abs(relativeAngleOfShipFromAlien(ship,alien)) < minAngleofRotation)
		ship.SetAngle(shipAngle+relativeAngle(ship,alien));//check
	else
		ship.SetAngle(shipAngle+angularvelocity);//change the sign of this according to where the alien is
}