#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <vector>
#include "Board.h"
using namespace std;


void display(void);
int graphics(int argc,char *argv[], Board board);
#endif