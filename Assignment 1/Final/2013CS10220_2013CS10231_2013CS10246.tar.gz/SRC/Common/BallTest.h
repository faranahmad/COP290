#ifndef BALLTEST_H
#define BALLTEST_H

bool RunAllBallTests();
bool BallInitialisationTests();
bool SettingBallTests();
bool UpdateBallTests();

#endif