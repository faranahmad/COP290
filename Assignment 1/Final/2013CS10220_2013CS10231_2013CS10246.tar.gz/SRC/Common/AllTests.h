#ifndef AllTESTS_H
#define AllTESTS_H

bool RunAllTests();

#endif