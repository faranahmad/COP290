#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <vector>
#include "3DBoard.h"
using namespace std;


void display(void);
int graphics(int argc,char *argv[], Board board);

#endif