#ifndef BOARDTEST_H
#define BOARDTEST_H

bool RunAllBoardTests();
bool BoardInitialisationTests();
bool SettingBoardTests();
bool BoardAddRemoveBallTests();

#endif